

  anime({
    targets: '.start-div',
    keyframes: [
        {gap : "15px"},
        {gap : '30px'},
    ],
    easing: 'easeInOutExpo',
    duration: 1500,
    loop: true
  });


