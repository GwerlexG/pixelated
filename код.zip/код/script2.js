console.log(document.cookie)
function getcookie(){
    let cookie_string = document.cookie
    let cookie_result = cookie_string.split(";")[0]
    let cookie_name = cookie_result.split("=")[0]
    if (cookie_name =="pixelated-result"){
        cookie_result=cookie_result.split("=")[1]
        cookie_result=cookie_result.split(",")
        return cookie_result
    }
    else {
        return 0
    }
}
function decodecolor(index){
    console.log(index)
    return colorlist[index]
}
let group=document.querySelector(".group")
let cookie_list=getcookie()

for (let i=0; i<144;i+=1){
    let newtile= document.createElement("div")
    newtile.classList.add("tile")
    group.appendChild(newtile)
    if (cookie_list !=0){
        newtile.style.backgroundColor=decodecolor(+cookie_list[i])
    }
    else {
        newtile.style.backgroundColor="#FFF1E8"
    }
}
let current_ins="none"
let current_color="none"

let black_button=document.querySelector(".black")
black_button.addEventListener("click", function(){current_color="black"})
let pen_button=document.querySelector(".pen")
let bucket_button=document.querySelector(".bucket")
pen_button.addEventListener("click", function(){
    current_ins="pen"
    current_color=last_color
})
bucket_button.addEventListener("click", function(){
    current_ins="bucket"
    current_color=last_color
})
let eraser_button=document.querySelector(".eraser")
eraser_button.addEventListener("click", function(){
    current_ins="eraser"
    current_color="white"
})
let colors=document.querySelectorAll(".color")
let last_color = "white"



colors.forEach(element => {
    element.addEventListener("click",function(){
        if (current_ins != "eraser"){
            current_color=getComputedStyle(element).backgroundColor
            console.log(current_color)
            last_color=current_color
        }
     })

});
let check_mouse=false
let tiles=document.querySelectorAll(".tile")
tiles.forEach(element => {
    element.addEventListener("click",function(){
        if (current_ins=="pen" || current_ins=="eraser"){
            element.style.backgroundColor=current_color
        }
        else if (current_ins=="bucket"){
            tiles.forEach(element1 => {
                element1.style.backgroundColor=current_color
            })
        }
    })
    element.addEventListener("mouseover", function(){
        if (check_mouse==true){
            if (current_ins=="pen" || current_ins=="eraser"){
                element.style.backgroundColor=current_color
            }
        }
    })
    console.log(check_mouse)
})
document.addEventListener("mousedown", function(){
    check_mouse=true
})
document.addEventListener("mouseup",function(){
    check_mouse=false
})
let colorlist=["#000000","1D2B53","#7E2553","#008751","#AB5236","#5F574F","#C2C3C7","#FFF1E8","#FF004D","#FFA300","#FFEC27","#00E436","#29ADFF","#83769C","#FFCCAA"]

function convertcolor(tile_color){
    let index=colorlist.indexOf(tile_color)
    return index
}


setInterval(function() {
    let result=""
    tiles.forEach(element => {
        let tile_color_hex = getComputedStyle(element).backgroundColor
        let index_color = String(convertcolor(tile_color_hex))
        result+=index_color + ","
        console.log(tile_color_hex)
        
    })
    result=result.slice(0,-1)
    console.log(result)
    document.cookie = `pixelated-result=${result};max-age=100000`
}, 10000)

